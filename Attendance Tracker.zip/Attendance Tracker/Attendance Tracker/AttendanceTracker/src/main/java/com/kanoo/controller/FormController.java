package com.kanoo.controller;

import com.kanoo.model.Person;
import com.kanoo.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class FormController {

    private final PersonService personService;

    @Autowired
    public FormController(PersonService personService) {
        this.personService = personService;
    }

    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("person", new Person());
        model.addAttribute("persons", personService.findAll());
        return "form";
    }

    @PostMapping("/submit")
    public String submitForm(@ModelAttribute Person person) {
        personService.save(person);
        return "redirect:/";
    }

    // New method to handle viewing attendance records
    @GetMapping("/view")
    public String viewAttendance(Model model) {
        model.addAttribute("persons", personService.findAll());
        return "view"; // This should correspond to your view.html
    }
    @PostMapping("/deleteAll")
    public String deleteAllRecords() {
        personService.deleteAll();
        return "redirect:/"; // Redirect to the form page after deletion
    }

}
