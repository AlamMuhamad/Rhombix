package com.kanoo.service;

import com.kanoo.model.Person;
import com.kanoo.repo.PersonRepository; // Ensure you have this repository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonService {

    private final PersonRepository personRepository;

    @Autowired
    public PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public List<Person> findAll() {
        return personRepository.findAll();
    }

    public void save(Person person) {
        personRepository.save(person);
    }
    public void deleteAll() {
        // Code to delete all records from the repository
        personRepository.deleteAll(); // Assuming you're using a Spring Data repository
    }
}
